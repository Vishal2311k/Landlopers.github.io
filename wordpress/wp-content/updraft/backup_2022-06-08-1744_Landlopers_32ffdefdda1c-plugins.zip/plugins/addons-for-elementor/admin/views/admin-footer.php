<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

    <div id="lae-infobox">
        <div class="lae-info-overlay"></div>
        <div class="lae-info-inner">
            <div class="lae-infobox-msg"></div>
        </div>
    </div>

</div><!-- lae-wrap -->